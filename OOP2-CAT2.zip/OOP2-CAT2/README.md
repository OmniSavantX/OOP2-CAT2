# OOP2-CAT2
 This is a simple JavaFx RMI application documented using javadocs.
